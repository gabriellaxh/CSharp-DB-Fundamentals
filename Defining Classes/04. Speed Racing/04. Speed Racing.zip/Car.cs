﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Car
{
    public string Model  { get; set; } 
    public double FuelAmount { get; set; }
    public double FuelConsumpPerKm { get; set; }
    public double DistanceTraveled { get; set; }
}

